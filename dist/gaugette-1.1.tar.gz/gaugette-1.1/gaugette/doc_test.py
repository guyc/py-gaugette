from spreadsheet import Spreadsheet 

SPREADSHEET_NAME = "TimeClock"
ss = Spreadsheet()
if not ss.get_spreadsheet_by_name(SPREADSHEET_NAME):
    print "Spreadsheet %s not found." % name
    exit

    
